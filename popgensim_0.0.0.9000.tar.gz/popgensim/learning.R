# c++ standard library # https://en.wikipedia.org/wiki/C%2B%2B_Standard_Library


# tutorial http://adv-r.had.co.nz/Rcpp.html

# tutorial install boost library http://www.boost.org/doc/
#include <boost/array.hpp>;
#include <numeric>

# work with algorithms http://www.cplusplus.com/reference/algorithm/
#include <algorithm>

# data structures http://www.cplusplus.com/reference/stl/

################################################################################
# To start the package
Rcpp.package.skeleton("popgensim", example_code = FALSE,
                      cpp_files = c("rumSumsC.cpp",'allelesim.cpp'))

# In DESCRIPTION add
#
# LinkingTo: Rcpp
# Imports: Rcpp
# Make sure your NAMESPACE includes:
#
# useDynLib(mypackage)
# importFrom(Rcpp, sourceCpp)
# We need to import something (anything) from Rcpp so that internal Rcpp code is properly loaded. This is a bug in R and hopefully will be fixed in the future.
#

################################################################################
# Some examples from http://adv-r.had.co.nz/Rcpp.html
library(Rcpp)
library(dplyr)

sourceCpp('src/rowSumsC.cpp')

data("iris")
iris[,1:4] %>% class()
rowSumsC(as.matrix(iris[,1:4]))

################################################################################
library(Rcpp)
library(RcppArmadillo)
library(ggplot2)
library(cowplot)
library(devtools)
# devtools::load_all(".")
install(".")



# Rcpp::sourceCpp('src/allelesimC.cpp')
allelesimCvec()
allelesimCmat(rep = 100,tmax=50)

library(microbenchmark)

allelesim(rep = 10,tmax=50)

microbenchmark(
  Rimplement=allelesim(rep = 10,tmax=50),
  Cimplement=allelesimCmat(rep = 10,tmax=50)
)
# mu=0.001
# nu=0.001
# m=0
# wAA=0.5
# wAa=0.5
# waa=0.5
# p0=0.5
# psource=0.5
# tmax=100
# d=0.3
# N=1000
# rep=50
#

# ps<-alleleFreq(mu, nu, m, wAA=0.55, wAa, waa, p0, psource, tmax, d, N,rep=10)
#
# library(moiR)
# library(ggplot2); library(cowplot)
# p <- basefreqplot(tmax)
# p<-addtrajectories(pn,rep,tmax,thecol=transparent("grey") )
# p<-addtrajectories(ps,rep=10,tmax,thecol="green4")
# p
