# Interactive shiny R plot of allele frequencies under a Wright-Fisher population

Tune the forces of evolution: mutation, migration, selection, and drift (including also non-random mating); to simulate allele frequencies under the classic population genetics equations.

### To get the package
``` sh
git clone https://github.com/MoisesExpositoAlonso/popgensim.git

``` 

### To run the Shinny app
``` sh
library(devtools)
library(shinny)

# Without having to previously clone it:
runGitHub("popgensim","MoisesExpositoAlonso")

# Needs git clone above, and from inside the folder:
runApp(".")

```

### To run simulations independently of the Shinny app, run:

```
# Packages required
library(ggplot) # for plots
library(cowplot) # for better plotting
library(shiny) # for the interactive app
library(devtools)
library(microbenchmark)
install(".")

# Run an example simulation comparing the R implementation
and the C++ implementation

microbenchmark(
  Rimplement=allelesim(rep = 10,tmax=50),
    Cimplement=allelesimCmat(rep = 10,tmax=50)
    )

# To further tune the simulations, you can define each of the population
parameters:

allelesimCmat(
mu=0.001,
nu=0.001,
m=0,
wAA=0.5,
wAa=0.5,
waa=0.5,
p0=0.5,
psource=0.5,
N=1000,
tmax=100,
rep=50)


```
