R -e "shiny::runApp('.')"
